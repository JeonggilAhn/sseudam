package elevenjo.ssdam.global.exception;

public class BaseException extends Exception {
	public BaseException() {
	}
}
