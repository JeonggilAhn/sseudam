package elevenjo.ssdam.global.exception;

public class BaseRuntimeException extends RuntimeException {
	public BaseRuntimeException() {

	}
}
